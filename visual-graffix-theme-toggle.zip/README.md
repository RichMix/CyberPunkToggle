# Visual Graffix Theme Toggle — Boilerplate

A tiny, dependency-free dark/light ("Matrix" / "Cyberpunk") theme system you
can drop into any static site, framework app, or component library.

## What's in this zip

- `index.html` — a complete example page wired up and ready to open in a browser.
- `theme-toggle.css` — CSS variables and example styles for both themes.
- `theme-toggle.js` — the toggle logic (localStorage persistence, OS preference detection).

## Quick start

1. Unzip this folder and open `index.html` directly in your browser to see it working.
2. Copy `theme-toggle.css` and `theme-toggle.js` into your own project.
3. Link both files in your page's `<head>`:
   ```html
   <link rel="stylesheet" href="theme-toggle.css" />
   <script src="theme-toggle.js"></script>
   ```
4. Initialize once the DOM is ready:
   ```html
   <script>VGThemeToggle.init();</script>
   ```
5. Style your CSS using the `.cyberpunk` class on `<html>`:
   ```css
   html.cyberpunk body { background: #fff; color: #1a1a1a; }
   html:not(.cyberpunk) body { background: #000; color: #4ADE80; }
   ```
6. Toggle the theme from any button:
   ```html
   <button onclick="VGThemeToggle.toggle()">Toggle theme</button>
   ```

## API

- `VGThemeToggle.init()` — restores the saved theme (or OS preference) and applies it. Call once on page load.
- `VGThemeToggle.toggle()` — flips between `matrix` and `cyberpunk`, returns the new theme name.
- `VGThemeToggle.setTheme(theme)` — sets a specific theme (`'matrix'` or `'cyberpunk'`).
- `VGThemeToggle.getTheme()` — returns the current theme name.

Free to use, modify, and redistribute in your own projects.
