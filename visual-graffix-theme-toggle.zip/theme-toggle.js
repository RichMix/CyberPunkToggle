/*!
 * Visual Graffix — Matrix / Cyberpunk Theme Toggle
 * A tiny, dependency-free dark/light theme system you can drop into any
 * static site or SPA. Adds a `.cyberpunk` class to <html> for "light mode"
 * and leaves it off for the default "dark / matrix mode", persists the
 * choice in localStorage, and respects the visitor's OS color-scheme on
 * first visit.
 *
 * USAGE
 *   1. Include this file: <script src="theme-toggle.js"></script>
 *   2. Call VGThemeToggle.init() once the DOM is ready.
 *   3. Style your CSS using the `.cyberpunk` class on <html>, e.g.
 *        html.cyberpunk body { background: #fff; color: #1a1a1a; }
 *        html:not(.cyberpunk) body { background: #000; color: #4ADE80; }
 *   4. Call VGThemeToggle.toggle() from any button's onclick.
 *
 * Free to use, modify, and redistribute in your own projects.
 */
(function (global) {
  'use strict';

  var STORAGE_KEY = 'vg-theme';
  var LIGHT_CLASS = 'cyberpunk';

  function getStoredTheme() {
    try {
      return global.localStorage.getItem(STORAGE_KEY);
    } catch (_e) {
      return null;
    }
  }

  function storeTheme(theme) {
    try {
      global.localStorage.setItem(STORAGE_KEY, theme);
    } catch (_e) {
      /* localStorage unavailable — theme just won't persist */
    }
  }

  function prefersLight() {
    return (
      global.matchMedia &&
      global.matchMedia('(prefers-color-scheme: light)').matches
    );
  }

  function applyTheme(theme) {
    var root = global.document.documentElement;
    if (theme === 'cyberpunk') {
      root.classList.add(LIGHT_CLASS);
    } else {
      root.classList.remove(LIGHT_CLASS);
    }
    global.document.dispatchEvent(
      new CustomEvent('vg-theme-change', { detail: { theme: theme } })
    );
  }

  function currentTheme() {
    return global.document.documentElement.classList.contains(LIGHT_CLASS)
      ? 'cyberpunk'
      : 'matrix';
  }

  function setTheme(theme) {
    applyTheme(theme);
    storeTheme(theme);
  }

  function toggle() {
    var next = currentTheme() === 'matrix' ? 'cyberpunk' : 'matrix';
    setTheme(next);
    return next;
  }

  function init() {
    var stored = getStoredTheme();
    var theme = stored || (prefersLight() ? 'cyberpunk' : 'matrix');
    applyTheme(theme);
    return theme;
  }

  global.VGThemeToggle = {
    init: init,
    toggle: toggle,
    setTheme: setTheme,
    getTheme: currentTheme,
  };
})(typeof window !== 'undefined' ? window : this);
